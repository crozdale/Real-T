// import React from 'react';

export default {
    message: '',
    // message: <h4>
    //     Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
    // </h4>,
    columns: 2,
    wrapperStyle: ''
};
