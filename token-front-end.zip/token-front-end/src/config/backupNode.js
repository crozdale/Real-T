const infura = `https://mainnet.infura.io/v3/${process.env.INFURA_PROJECT_ID}`;
export default infura;