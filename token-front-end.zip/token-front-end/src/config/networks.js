export default {
    0: 'Private',
    1: 'Mainnet',
    2: 'Mordern',
    3: 'Ropsten',
    4: 'Rinkeby',
    42: 'Kovan'
};