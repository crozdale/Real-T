export default {
    tokenName: 'name()',
    tokenSymbol: 'symbol()',
    tokenDecimals: 'decimals()'
};