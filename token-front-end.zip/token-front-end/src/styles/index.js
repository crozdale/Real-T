export { footerStyle } from './footer';
export { headerStyle } from './header';
export { contentStyle } from './content';